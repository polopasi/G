// Used when we need to compile with no source code
// (controls are in the command-line)
